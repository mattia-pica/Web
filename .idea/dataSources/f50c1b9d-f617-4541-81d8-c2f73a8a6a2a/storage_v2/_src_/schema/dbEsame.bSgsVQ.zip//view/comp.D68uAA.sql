CREATE VIEW comp AS
  SELECT substr(`dbEsame`.`Aule`.`nome`, 6) AS `SUBSTRING(nome, 6)`
  FROM `dbEsame`.`Aule`;

